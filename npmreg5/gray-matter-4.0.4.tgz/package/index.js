module.exports = function () { return 'stub'; };
